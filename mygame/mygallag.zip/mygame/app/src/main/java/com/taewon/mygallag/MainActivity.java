package com.taewon.mygallag;

import android.content.Intent;
import android.graphics.Point;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.Display;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import io.github.controlwear.virtual.joystick.android.JoystickView;

public class MainActivity extends AppCompatActivity {
    private Intent userIntent;
    int bgMusicIndex;
    ArrayList<Integer> bgMusicList;
    public static SoundPool effectSound;
    public static float effectVolumn;
    ImageButton specialShotBtn;
    public static ImageButton fireBtn, reladBtn;
    JoystickView joyStick;
    public static TextView scoreTv;
    LinearLayout gameFrame;
    ImageView pauseBtn;
    public static LinearLayout lifeFrame;

    SpaceInvadersView spaceInvadersView;

    public static MediaPlayer bgMusic;

    public static TextView bulletCount;

    private static ArrayList<Integer> effectSoundList;
    public static final int PLAYER_SHOT = 0;
    public static final int PLAYER_HURT = 1;
    public static final int PLAYER_RELOAD = 2;
    public static final int PLAYER_GET_ITEM = 3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        userIntent = getIntent();
        bgMusicIndex = 0;
        bgMusicList = new ArrayList<Integer>();  //음악 넣을 arrayList 생성
        bgMusicList.add(R.raw.main_game_bgm1);
        bgMusicList.add(R.raw.main_game_bgm2);
        bgMusicList.add(R.raw.main_game_bgm3);

        effectSound = new SoundPool(5, AudioManager.USE_DEFAULT_STREAM_TYPE,0);
        effectVolumn = 1;

        specialShotBtn = findViewById(R.id.specialShotBtn); //스페셜 스킬
        joyStick = findViewById(R.id.joyStick); //조이스틱
        scoreTv = findViewById(R.id.score);   //스코어 TextView
        fireBtn = findViewById(R.id.fireBtn);  //발사 button
        reladBtn = findViewById(R.id.reloadBtn); //재장전 버튼
        gameFrame = findViewById(R.id.gameFrame);  //화면 전체 Frame
        pauseBtn = findViewById(R.id.pauseBtn);   //일시정지 버튼
        lifeFrame = findViewById(R.id.lifeFrame);  //생명하트 Frame

        init();

    }

    @Override
    protected void onResume() {
        super.onResume();
        bgMusic.start();
        spaceInvadersView.resume();
    }
    private void init(){
        Display display = getWindowManager().getDefaultDisplay(); //view의 display를 얻어온다
        Point size = new Point();
        display.getSize(size);

        spaceInvadersView = new SpaceInvadersView(this,userIntent.getIntExtra("character",R.drawable.ship_0000),size.x,size.y);
        gameFrame.addView(spaceInvadersView); //프레임에 만든 item들 넣기

        //음악 바꾸기
        changeBgMusic();
        bgMusic.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { //음악이 끝나면
            @Override
            public void onCompletion(MediaPlayer mp) { changeBgMusic(); }
        });
        bulletCount = findViewById(R.id.bulletCount); //총알 개수

        //spaceInvadersView의 getPlayer() 구현
        bulletCount.setText(spaceInvadersView.getPlayer().getBulletsCount() + "/30");  // 30/30 표시
        scoreTv.setText(Integer.toString(spaceInvadersView.getScore()));  //score : 0 표시

        effectSoundList = new ArrayList<>();
        effectSoundList.add(PLAYER_SHOT,effectSound.load(MainActivity.this,R.raw.player_shot_sound,1));
        effectSoundList.add(PLAYER_HURT,effectSound.load(MainActivity.this,R.raw.player_hurt_sound,1));
        effectSoundList.add(PLAYER_RELOAD,effectSound.load(MainActivity.this,R.raw.reload_sound,1));
        effectSoundList.add(PLAYER_GET_ITEM,effectSound.load(MainActivity.this,R.raw.player_get_item_sound,1));
        bgMusic.start(); //음악이 바뀌면서 재생
    }
    private void changeBgMusic(){
        bgMusic = MediaPlayer.create(this,bgMusicList.get(bgMusicIndex)); //음악하나 가져와 만들기
        bgMusic.start();
        bgMusicIndex++;
        bgMusicIndex = bgMusicIndex % bgMusicList.size();
    }
}