package com.taewon.mygallag.items;



public class HealitemSprite{
}
