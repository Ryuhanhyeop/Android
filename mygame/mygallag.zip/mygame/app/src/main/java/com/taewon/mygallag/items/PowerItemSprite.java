package com.taewon.mygallag.items;


public class PowerItemSprite {
}
